// --- Типы ---
import { JSONSchema7 } from 'json-schema';

export type PortDataType = 'string' | 'number' | 'boolean' | 'object' | 'array' | 'file';

export interface Port {
  name: string;
  type: PortDataType;
  schema?: JSONSchema7;
}

export interface Link {
  id: string;
  fromStepId: string;
  fromPort: string;
  toStepId: string;
  toPort: string;
}

export interface ExecutableCode {
  language: 'javascript' | 'python';
  sourceCode: string;
}

export type StepConfig = Record<string, unknown>;

export interface Step {
  id: string;
  name: string;
  type: 'code' | 'api_call' | 'transform' | 'condition' | 'loop';
  description?: string;
  inputs: Port[];
  outputs: Port[];
  config: Record<string, unknown>;
  configSchema?: JSONSchema7;
  code?: ExecutableCode;
}

export interface Skill {
  id: string;
  name: string;
  description?: string;
  steps: SkillStepInstance[];
  links: Link[];
  startStepId: string;
}

export type ExecutionContext = Record<string, unknown>;

// --- Исполнение шагов ---
export interface StepExecutor {
  execute(
    step: StepTemplate,
    inputs: Record<string, unknown>,
    context: ExecutionContext,
  ): Promise<Record<string, unknown>>;
}

export interface Port {
  name: string;
  type: PortDataType;
  schema?: JSONSchema7;
}

export interface ExecutableCode {
  language: 'javascript' | 'python';
  sourceCode: string;
}

// 🔹 StepTemplate — шаблон переиспользуемого шага
export interface StepTemplate {
  id: string;
  name: string;
  type: 'code' | 'api_call' | 'transform' | 'condition' | 'loop';
  description?: string;
  inputs: Port[];
  outputs: Port[];
  configSchema?: JSONSchema7;
  code?: ExecutableCode;
}

// 🔹 SkillStepInstance — конфигурация шага в рамках навыка
export interface SkillStepInstance {
  id: string;
  name: string;
  templateId: string;
  config: Record<string, unknown>;
  inputs: Port[];
  outputs: Port[];
}

export interface Link {
  id: string;
  fromStepId: string;
  fromPort: string;
  toStepId: string;
  toPort: string;
}

// 🔹 Execution log
export interface SkillExecutionLog {
  id: string;
  skillId: string;
  timestamp: string;
  context: ExecutionContext;
}

// 🔹 Ответ при запуске навыка
export interface SkillRunResult {
  context: ExecutionContext;
  logId: string;
}
