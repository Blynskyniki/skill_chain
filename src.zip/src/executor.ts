import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import { tmpdir } from 'os';
import Ajv from 'ajv';
import { ExecutionContext, Port, Skill, StepExecutor, StepTemplate } from './types';

const ajv = new Ajv();

export class CodeStepExecutor implements StepExecutor {
  async execute(
    step: StepTemplate,
    inputs: Record<string, unknown>,
    context: ExecutionContext,
  ): Promise<Record<string, unknown>> {
    console.log(`🔄 Шаг [${step.name}] (${step.id}) - старт`);
    this.validatePorts(step.inputs, inputs, 'input');

    const { language, sourceCode } = step.code!;
    let result: Record<string, unknown> = {};

    if (language === 'javascript') {
      const vm = await import('vm2');
      const { VM } = vm;
      const sandbox = { ...inputs, context, console };
      const script = new VM({ sandbox });
      result = script.run(`(function() { ${sourceCode} })()`);
    } else if (language === 'python') {
      const tempFilePath = path.join(tmpdir(), `step_${step.id}.py`);
      await fs.writeFile(tempFilePath, sourceCode, 'utf-8');
      result = await new Promise((resolve, reject) => {
        const proc = spawn('python3', [tempFilePath], { stdio: ['pipe', 'pipe', 'inherit'] });
        const stdout: Buffer[] = [];
        proc.stdout.on('data', chunk => stdout.push(chunk));
        proc.stdin.write(JSON.stringify(inputs));
        proc.stdin.end();
        proc.on('close', () => {
          try {
            resolve(JSON.parse(Buffer.concat(stdout).toString()));
          } catch (e) {
            reject(e);
          }
        });
      });
    } else {
      throw new Error(`Unsupported language: ${language}`);
    }

    this.validatePorts(step.outputs, result, 'output');
    console.log(`✅ Шаг [${step.name}] (${step.id}) - завершён`);
    return result;
  }

  private validatePorts(ports: Port[], data: Record<string, unknown>, mode: 'input' | 'output') {
    for (const port of ports) {
      const value = data[port.name];
      if (port.schema) {
        const validate = ajv.compile(port.schema);
        const valid = validate(value);
        if (!valid) {
          throw new Error(`Validation error in ${mode} '${port.name}': ${JSON.stringify(validate.errors)}`);
        }
      }
    }
  }
}

// --- Исполнение навыка как граф ---
export class SkillExecutor {
  constructor(
    private skill: Skill,
    private stepExecutors: Record<string, StepTemplate>,
  ) {}

  async run(context: ExecutionContext = {}): Promise<ExecutionContext> {
    const executedSteps = new Set<string>();
    const outputs: Record<string, Record<string, unknown>> = {};
    const queue: string[] = [this.skill.startStepId];

    while (queue.length > 0) {
      const stepId = queue.shift()!;
      if (executedSteps.has(stepId)) continue;

      const s = this.skill.steps.find(s => s.id === stepId);
      if (!s) throw new Error(`Step '${stepId}' not found`);

      const inputData: Record<string, unknown> = {};
      for (const link of this.skill.links.filter(l => l.toStepId === s.id)) {
        inputData[link.toPort] = outputs[link.fromStepId]?.[link.fromPort];
      }

      const step: StepTemplate = this.stepExecutors[s.id];
      const executor = new CodeStepExecutor();
      const result = await executor.execute(step, inputData, context);
      outputs[step.id] = result;
      executedSteps.add(step.id);

      for (const link of this.skill.links.filter(l => l.fromStepId === step.id)) {
        queue.push(link.toStepId);
      }
    }

    return context;
  }
}
