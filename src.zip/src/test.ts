// seed.ts — инициализация демо-данных
import { promises as fs } from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { Skill, StepTemplate } from './types';

async function seed() {
  const tpl1Id = uuidv4();
  const tpl2Id = uuidv4();

  const stepTemplates: StepTemplate[] = [
    {
      id: tpl1Id,
      name: 'Log Input',
      type: 'code',
      description: 'Логирует входные данные',
      inputs: [{ name: 'input', type: 'string' }],
      outputs: [{ name: 'output', type: 'string' }],
      code: {
        language: 'javascript',
        sourceCode: `console.log('📥 input =', input); return { output: input };`,
      },
    },
    {
      id: tpl2Id,
      name: 'Append Text',
      type: 'code',
      description: 'Добавляет "_done" к строке',
      inputs: [{ name: 'text', type: 'string' }],
      outputs: [{ name: 'result', type: 'string' }],
      code: {
        language: 'javascript',
        sourceCode: `return { result: text + '_done' };`,
      },
    },
  ];

  const skillId = uuidv4();
  const step1Id = uuidv4();
  const step2Id = uuidv4();

  const skill: Skill = {
    id: skillId,
    name: 'Демо навык',
    description: 'Навык из двух шагов',
    startStepId: step1Id,
    steps: [
      {
        id: step1Id,
        name: 'Вход',
        templateId: tpl1Id,
        config: {},
        inputs: [{ name: 'input', type: 'string' }],
        outputs: [{ name: 'output', type: 'string' }],
      },
      {
        id: step2Id,
        name: 'Модификация',
        templateId: tpl2Id,
        config: {},
        inputs: [{ name: 'text', type: 'string' }],
        outputs: [{ name: 'result', type: 'string' }],
      },
    ],
    links: [
      {
        id: uuidv4(),
        fromStepId: step1Id,
        fromPort: 'output',
        toStepId: step2Id,
        toPort: 'text',
      },
    ],
  };

  await fs.mkdir('data', { recursive: true });
  await fs.writeFile(path.join('data', 'step_templates.json'), JSON.stringify(stepTemplates, null, 2));
  await fs.writeFile(path.join('data', 'skills.json'), JSON.stringify([skill], null, 2));

  console.log('✅ Данные успешно записаны');
}

seed().catch(err => {
  console.error('💥 Ошибка при инициализации данных:', err);
});
